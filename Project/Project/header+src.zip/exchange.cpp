#include "head_er.h"

// PXM �������� ����
pxm temp(ifstream *file) {
	int line_cnt = 0, width, height, Findex = -1;
	string header_p, pixel, maximum_p;
	while (line_cnt != 4) {
		switch (line_cnt) {
		case 0:
			getline(*file, header_p);
			line_cnt++;
			break;

		case 1:
			getline(*file, pixel);
			while (pixel == "") getline(*file, pixel);
			line_cnt++;

			// pixel�� ���� �Ľ��� ������ �������� width�� height�� �и�
			Findex = pixel.find(" ", 0);
			if (Findex != -1) {
				width = stoi(pixel.substr(0, Findex));
				height = stoi(pixel.substr(Findex + 1, pixel.length()));
				line_cnt++;
			}
			break;

			// �� line�� ���� ��� width������ �����ϰ� �ٸ� ���ο��� ã��
		case 2:
			width = stoi(pixel);
			getline(*file, pixel);
			height = stoi(pixel);
			line_cnt++;
			break;

			// maximum�� ã��
		case 3:
			getline(*file, maximum_p);
			while (maximum_p == "") getline(*file, maximum_p);
			line_cnt++;
			break;

		default:
			break;
		}
	}

	pxm rep = {0};
	unsigned char *img;
	if (header_p == "P5") {
		img = new unsigned char[width * height];
		file->read((char*)img, width * height);
	}

	else {
		img = new unsigned char[width * height * 3];
		file->read((char*)img, width * height * 3);
	}

	rep.width = width;
	rep.height = height;
	rep.img = img;

	return rep;
}

// bmp pixel �޾ƿ���
unsigned char *get_bmp_img(myBITMAPFILEHEADER f_Header, myBITMAPINFOHEADER b_Header, myRGBQUAD *c_table, ifstream *file) {
	int whole_width = (((b_Header.biBitCount * b_Header.biWidth) + 31) / 32 * 4);

	unsigned char *img;

	if (b_Header.biBitCount == 24) img = bmp_24(f_Header, b_Header, whole_width, file, 4);
	else img = bmp_o(f_Header, b_Header, whole_width, file, c_table, 5);
	return img;
}

void exchange_bmp(ifstream *file, string filetype) {
	myBITMAPFILEHEADER f_Header;
	file->read((char*)&f_Header.bfType, 2);
	file->read((char*)&f_Header.bfSize, 4);
	file->read((char*)&f_Header.bfReserved1, 2);
	file->read((char*)&f_Header.bfReserved2, 2);
	file->read((char*)&f_Header.bfOffBits, 4);

	myBITMAPINFOHEADER b_Header;
	file->read((char*)&b_Header.biSize, 4);
	file->read((char*)&b_Header.biWidth, 4);
	file->read((char*)&b_Header.biHeight, 4);
	file->read((char*)&b_Header.biPlanes, 2);
	file->read((char*)&b_Header.biBitCount, 2);
	file->read((char*)&b_Header.biCompression, 4);
	file->read((char*)&b_Header.biSizeImage, 4);
	file->read((char*)&b_Header.biXPelsPerMeter, 4);
	file->read((char*)&b_Header.biYPelsPerMeter, 4);
	file->read((char*)&b_Header.biClrUsed, 4);
	file->read((char*)&b_Header.biClrImportant, 4);

	myRGBQUAD c_table[256];
	if (b_Header.biBitCount != 24) file->read((char*)c_table, f_Header.bfOffBits - 54);

	unsigned char *img;
	unsigned char *pxm = new unsigned char[b_Header.biWidth * b_Header.biHeight * 3];
	img = get_bmp_img(f_Header, b_Header, c_table, file);

	int temp = 0;

	// �е�ó��
	int whole_width = (((b_Header.biBitCount * b_Header.biWidth) + 31) / 32 * 4);

	// bmp -> ppm
	if (filetype == "ppm") {
		if (b_Header.biBitCount == 8) {
			// ���� ��� ���� ����
			ofstream fout("output.ppm", ios::binary);
			fout << "P6" << (char)10;
			fout << b_Header.biWidth << ' ' << b_Header.biHeight << (char)10 << 255 << (char)10;

			// img ���Ϲ���
			for (int i = 0; i < b_Header.biHeight; i++) for (int j = 0; j < b_Header.biWidth; j++)  *(pxm + i * b_Header.biWidth + j) = *(img + (b_Header.biHeight - i - 1) * whole_width + j);
			for (int i = 0; i < b_Header.biHeight * b_Header.biWidth; i++) *(img + i) = *(pxm + i);

			// �ȼ� �߰�
			for (int i = 0, j = 0; i < b_Header.biWidth * b_Header.biHeight; i++, j += 3) {
				temp = *(img + i);
				*(pxm + j) = c_table[temp].rgbRed;
				*(pxm + j + 1) = c_table[temp].rgbGreen;
				*(pxm + j + 2) = c_table[temp].rgbBlue;
			}

			// makeBox
			makeBox(pxm, b_Header.biWidth, b_Header.biHeight, whole_width, 1);

			// ���� ����
			fout.write((char*)pxm, b_Header.biWidth * b_Header.biHeight * 3);
			cout << "output.ppm ������ �����Ǿ����ϴ�." << endl;
		}

		else if (b_Header.biBitCount == 24) {
			// ���� ��� ���� ����
			ofstream fout("output.ppm", ios::binary);
			fout << "P6" << (char)10;
			fout << b_Header.biWidth << ' ' << b_Header.biHeight << (char)10 << 255 << (char)10;

			// img ���Ϲ��� �� �ȼ� �߰�
			for (int i = 0; i < b_Header.biHeight; i++)	for (int j = 0; j < b_Header.biWidth; j++) for (int h = 0; h < 3; h++) *(pxm + i * b_Header.biWidth * 3 + j * 3 + h) = *(img + (b_Header.biHeight - i - 1) * whole_width + j * 3 + 2 - h);

			// makeBox
			makeBox(pxm, b_Header.biWidth, b_Header.biHeight, whole_width, 1);

			// ���� ����
			fout.write((char*)pxm, b_Header.biWidth * b_Header.biHeight * 3);
			cout << "output.ppm ������ �����Ǿ����ϴ�." << endl;
		}
	}

	// bmp -> pgm
	else if (filetype == "pgm") {
		if (b_Header.biBitCount == 8) {
			// ���� ��� ���� ����
			ofstream fout("output.pgm", ios::binary);
			fout << "P5" << (char)10;
			fout << b_Header.biWidth << ' ' << b_Header.biHeight << (char)10 << 255 << (char)10;

			// img ���Ϲ���
			for (int i = 0; i < b_Header.biHeight; i++) for (int j = 0; j < b_Header.biWidth; j++)  *(pxm + i * b_Header.biWidth + j) = *(img + (b_Header.biHeight - i - 1) * whole_width + j);
			for (int i = 0; i < b_Header.biHeight * b_Header.biWidth; i++) *(img + i) = *(pxm + i);

			// �ȼ� �߰�
			for (int i = 0, j = 0; i < b_Header.biWidth * b_Header.biHeight; i++) {
				temp = 0;
				temp += c_table[*(img + i)].rgbRed;
				temp += c_table[*(img + i)].rgbGreen;
				temp += c_table[*(img + i)].rgbBlue;
				*(pxm + i) = temp / 3;
			}

			// makeBox
			makeBox(pxm, b_Header.biWidth, b_Header.biHeight, whole_width, 0);

			// ���� ����
			fout.write((char*)pxm, b_Header.biWidth * b_Header.biHeight);
			cout << "output.pgm ������ �����Ǿ����ϴ�." << endl;
		}

		// ���� ��� ���� ����
		else if (b_Header.biBitCount == 24) {
			ofstream fout("output.pgm", ios::binary);
			fout << "P5" << (char)10;
			fout << b_Header.biWidth << ' ' << b_Header.biHeight << (char)10 << 255 << (char)10;

			// img ���Ϲ���
			for (int i = 0; i < b_Header.biHeight; i++) for (int j = 0; j < b_Header.biWidth; j++) *(pxm + i * b_Header.biWidth + j) = (*(img + (b_Header.biHeight - i - 1) * whole_width + j * 3) + *(img + (b_Header.biHeight - i - 1) * whole_width + j * 3 + 1) + *(img + (b_Header.biHeight - i - 1) * whole_width + j * 3 + 2)) / 3;

			// makeBox
			makeBox(pxm, b_Header.biWidth, b_Header.biHeight, whole_width, 0);

			// ���� ����
			fout.write((char*)pxm, b_Header.biWidth * b_Header.biHeight);
			cout << "output.pgm ������ �����Ǿ����ϴ�." << endl;
		}
	}

	// bmp -> error
	else cout << "����ε� ���� Ȯ���ڸ��� �Է����ּ���.\n";
	return;
}

void exchange_ppm(ifstream *file, string filetype) {
	pxm rep = { 0 };
	int px = 0, cnt = 0;
	unsigned char *ex_img;

	// BMP ��ȯ�� ���
	myBITMAPFILEHEADER f_Header = { 0 };
	myBITMAPINFOHEADER b_Header = { 0 };

	// �ȼ���
	rep = temp(file);
	ex_img = new unsigned char[rep.width * rep.height * 3];

	// ����
	for (int i = 0; i < rep.height; i++) for (int j = 0; j < rep.width; j++) for (int h = 0; h < 3; h++) *(rep.img + i * rep.width * 3 + j * 3 + h) = 255 - *(rep.img + i * rep.width * 3 + j * 3 + h);

	// ppm -> bmp
	if (filetype == "bmp") {
		// �������
		f_Header.bfType = 0x4D42;
		f_Header.bfSize = rep.width * rep.height * 3 + 56;
		f_Header.bfOffBits = 54;
		b_Header.biBitCount = 24;
		b_Header.biSize = 40;
		b_Header.biWidth = rep.width;
		b_Header.biHeight = rep.height;
		b_Header.biPlanes = 1;

		// �е�ó��
		int whole_width = (((b_Header.biBitCount * b_Header.biWidth) + 31) / 32 * 4);

		b_Header.biSizeImage = whole_width * rep.height;

		// ���Ϲ��� ������
		ex_img = new unsigned char[whole_width * rep.height];
		for (int i = 0; i < rep.height; i++) for (int j = 0; j < rep.width; j++) for (int h = 0; h < 3; h++) *(ex_img + i * whole_width + j * 3 + h) = *(rep.img + (rep.height - i - 1) * rep.width * 3 + j * 3 + 2 - h);

		// makeBox
		makeBox(ex_img, rep.width, rep.height, whole_width, 2);

		// ���� ����
		myRGBQUAD *c_table = { 0 };
		file_save(f_Header, b_Header, c_table, ex_img);
	}

	// ppm -> pgm
	else if (filetype == "pgm") {
		ex_img = new unsigned char[rep.width * rep.height];
		// �� ����
		for (int i = 0; i < rep.height; i++) {
			for (int j = 0; j < rep.width; j++) {
				for (int h = 0; h < 3; h++) px += *(rep.img + i * rep.width * 3 + j * 3 + h);
				*(rep.img + cnt) = px / 3;
				cnt++;
				px = 0;
			}
		}

		// makeBox
		makeBox(rep.img, rep.width, rep.height, -1, 0);

		// ���� ����
		ofstream fout("output.pgm", ios::binary);
		fout << "P5" << (char)10;
		fout << rep.width << ' ' << rep.height << (char)10 << 255 << (char)10;
		fout.write((char*)rep.img, rep.width * rep.height);
		cout << "output.pgm ������ �����Ǿ����ϴ�." << endl;
	}

	// ppm -> error
	else cout << "����ε� ���� Ȯ���ڸ��� �Է����ּ���.\n";

	return;
}

void exchange_pgm(ifstream *file, string filetype) {
	pxm rep = { 0 };
	int px = 0, cnt = 0;
	unsigned char *ex_img;

	// BMP ��ȯ�� ���
	myBITMAPFILEHEADER f_Header = { 0 };
	myBITMAPINFOHEADER b_Header = { 0 };

	// �ȼ���
	rep = temp(file);

	// ����
	for (int i = 0; i < rep.height; i++) for (int j = 0; j < rep.width; j++) *(rep.img + i * rep.width + j) = 255 - *(rep.img + i * rep.width + j);

	// pgm -> bmp
	if (filetype == "bmp") {
		// �������
		f_Header.bfType = 0x4D42;
		f_Header.bfSize = rep.width * rep.height * 3 + 56;
		f_Header.bfOffBits = 54;
		b_Header.biBitCount = 24;
		b_Header.biSize = 40;
		b_Header.biWidth = rep.width;
		b_Header.biHeight = rep.height;
		b_Header.biPlanes = 1;

		// �е�ó��
		int whole_width = (((b_Header.biBitCount * b_Header.biWidth) + 31) / 32 * 4);

		b_Header.biSizeImage = whole_width * rep.height + 2;

		// ���Ϲ��� ������
		ex_img = new unsigned char[whole_width * rep.height];
		for (int i = 0; i < rep.height; i++) for (int j = 0; j < rep.width; j++) for (int h = 0; h < 3; h++) *(ex_img + i * whole_width + j * 3 + h) = *(rep.img + (rep.height - i - 1) * rep.width + j);

		// makeBox
		makeBox(ex_img, rep.width, rep.height, whole_width, 2);

		// ���� ����
		myRGBQUAD *c_table = { 0 };
		file_save(f_Header, b_Header, c_table, ex_img);
	}

	// pgm -> ppm
	else if (filetype == "ppm") {
		ex_img = new unsigned char[rep.width * rep.height * 3];

		//������
		for (int i = 0; i < rep.height; i++) {
			for (int j = 0; j < rep.width; j++) {
				for (int h = 0; h < 3; h++) px += *(ex_img + i * rep.width * 3 + j * 3 + h) = *(rep.img + cnt);
				cnt++;
			}
		}

		// makeBox
		makeBox(ex_img, rep.width, rep.height, -1, 1);

		// ���� ����
		ofstream fout("output.ppm", ios::binary);
		fout << "P6" << (char)10;
		fout << rep.width << ' ' << rep.height << (char)10 << 255 << (char)10;
		fout.write((char*)ex_img, rep.width * rep.height * 3);
		cout << "output.ppm ������ �����Ǿ����ϴ�." << endl;
	}

	// pgm -> error
	else cout << "����ε� ���� Ȯ���ڸ��� �Է����ּ���.\n";
	return;
}

void exchange_file(string file_name) {
	// ���� ����
	ifstream checkHeader(file_name, ios::binary);
	ifstream file(file_name, ios::binary);

	myWORD fileHeader;
	string filetype;
	checkHeader.read((char*)&fileHeader, sizeof(myWORD));
	switch (fileHeader) {

	// bmp
	case 0x4D42:
		cout << "��ȯ��ų Ȯ���ڸ��� �Է����ּ���. : ";
		cin >> filetype;
		exchange_bmp(&file, filetype);
		file.close();
		checkHeader.close();
		break;

	// ppm
	case 0x3650:
		cout << "��ȯ��ų Ȯ���ڸ��� �Է����ּ���. : ";
		cin >> filetype;
		exchange_ppm(&file, filetype);
		file.close();
		checkHeader.close();
		break;

	// pgm
	case 0x3550:
		cout << "��ȯ��ų Ȯ���ڸ��� �Է����ּ���. : ";
		cin >> filetype;
		exchange_pgm(&file, filetype);
		file.close();
		checkHeader.close();
		break;

	// ����
	default:
		cout << "����ε� ���ϸ��� �Է����ּ���..\n";
		file.close();
		checkHeader.close();
		return;
	}
	return;
}