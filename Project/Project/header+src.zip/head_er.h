#pragma once

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string>
#include <math.h>
#include <stdlib.h>

typedef long				myLONG;
typedef unsigned long       myDWORD;
typedef unsigned char       myBYTE;
typedef unsigned short      myWORD;


struct myBITMAPFILEHEADER {
	myWORD    bfType;
	myDWORD   bfSize;
	myWORD    bfReserved1;
	myWORD    bfReserved2;
	myDWORD   bfOffBits;
};

struct myBITMAPINFOHEADER {
	myDWORD      biSize;
	myLONG       biWidth;
	myLONG       biHeight;
	myWORD       biPlanes;
	myWORD       biBitCount;
	myDWORD      biCompression;
	myDWORD      biSizeImage;
	myLONG       biXPelsPerMeter;
	myLONG       biYPelsPerMeter;
	myDWORD      biClrUsed;
	myDWORD      biClrImportant;
};

struct myRGBQUAD {
	myBYTE    rgbBlue;
	myBYTE    rgbGreen;
	myBYTE    rgbRed;
	myBYTE    rgbReserved;
};

// pxm ����
struct pxm {
	int width;
	int height;
	unsigned char *img;
};

using namespace std;

void exchange_file(string file_name);
void bmp_rgb(string file_name, int type);
void choose(myBITMAPFILEHEADER f_Header, myBITMAPINFOHEADER b_Header, myRGBQUAD *c_table, unsigned char *img);
unsigned char *bmp_o(myBITMAPFILEHEADER f_Header, myBITMAPINFOHEADER b_Header, int whole_width, ifstream *file, myRGBQUAD *c_table, int type);
unsigned char *bmp_24(myBITMAPFILEHEADER f_Header, myBITMAPINFOHEADER b_Header, int whole_width, ifstream *file, int type);
unsigned char *decode_RLE(unsigned char *img, myBITMAPINFOHEADER b_Header);
unsigned char* makeBox(unsigned char *img, int width, int height, int whole_width, int type);
void file_save(myBITMAPFILEHEADER f_Header, myBITMAPINFOHEADER b_Header, myRGBQUAD *c_table, unsigned char *img);